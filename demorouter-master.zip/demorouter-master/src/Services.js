import React from 'react';

class Services extends React.Component{
    render(){
        return(
            <div>
            <h1>Services page</h1>
            </div>
        )
    }
}

export default Services;