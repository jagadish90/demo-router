import React from 'react';

class Contactus extends React.Component{
    render(){
        return(
            <div>
            <h1>Contactus page</h1>
            </div>
        )
    }
}

export default Contactus;